JobID: cp264-a3
Name: Shawn Phung 
ID: 200814180

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description


Q1 My string functions
Q1.1 [3/3/*] str_length()                            
Q1.2 [4/4/*] word_count()                            
Q1.3 [3/3/*] lower_case()                            
Q1.4 [5/5/*] str_trim()                              

Q2 My word processor
Q2.1 [4/4/*] Data structures                         
Q2.2 [6/6/*] process_word(()                         
Q2.3 [5/5/*] save_file()                             

Total: [30/30/*]

Copy and paste the console output of your public test in the following. 
This will help markers to evaluate your program if it fails the marking tests.  

Q1 output:
str:"     This Is    a Test   String   "
str_length(str):34
word_count(str):5
str_trim(str):"this is a test string"
str_length(str_trim(str)):21

Q2 output:
word stats:value
line count:3
total word count:13
distinct word count:9

distinct words:frequency
this:2
is:2
the:2
first:1
test:2
second:1
cp264:1
data:1
structures:1

file contents
word stats:value
line count:3
total word count:13
distinct word count:9

distinct words:frequency
this:2
is:2
the:2
first:1
test:2
second:1
cp264:1
data:1
structures:1



